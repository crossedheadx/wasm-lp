fn main() {
  let s : &str = "Hello Edited from Cesare!";
  println!("{}", s);
}
